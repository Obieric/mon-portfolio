export type ProjectType = "mobile" | "web";

export interface Project {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  type: ProjectType;
  techStack: string[];
  imageUrl: string;
  githubUrl?: string;
  liveUrl?: string;
  appStoreUrl?: string;
  playStoreUrl?: string;
  challenges: string;
  features: string[];
}

export const projects: Project[] = [
  {
    id: "fitness-tracker",
    title: "FitPulse",
    description: "A cross-platform fitness tracking app with real-time workout analytics and social challenges.",
    longDescription: "FitPulse is a comprehensive fitness companion that tracks workouts, monitors progress, and connects users through social fitness challenges. Built with React Native for seamless cross-platform performance, it features real-time heart rate monitoring, custom workout plans, and an achievement system that keeps users motivated.",
    type: "mobile",
    techStack: ["React Native", "TypeScript", "Firebase", "Redux", "Reanimated"],
    imageUrl: "/placeholder.svg",
    githubUrl: "https://github.com",
    appStoreUrl: "https://apps.apple.com",
    playStoreUrl: "https://play.google.com",
    challenges: "Implementing smooth 60fps animations during real-time data updates while maintaining battery efficiency across both iOS and Android platforms.",
    features: ["Real-time workout tracking", "Social challenges", "Custom workout plans", "Progress analytics", "Heart rate monitoring"],
  },
  {
    id: "food-delivery",
    title: "QuickBite",
    description: "An on-demand food delivery app with live order tracking and AI-powered recommendations.",
    longDescription: "QuickBite revolutionizes food delivery with an intuitive ordering experience, real-time GPS tracking, and machine learning-powered restaurant recommendations. The app features a clean, gesture-driven interface and supports multiple payment methods including digital wallets.",
    type: "mobile",
    techStack: ["Flutter", "Dart", "Node.js", "MongoDB", "Google Maps API"],
    imageUrl: "/placeholder.svg",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    challenges: "Building a reliable real-time tracking system that handles thousands of concurrent delivery updates while keeping the UI responsive and battery-friendly.",
    features: ["Live GPS tracking", "AI recommendations", "Multi-payment support", "Real-time notifications", "Restaurant dashboard"],
  },
  {
    id: "meditation-app",
    title: "MindSpace",
    description: "A meditation and mindfulness app with guided sessions, sleep stories, and mood tracking.",
    longDescription: "MindSpace provides a serene digital sanctuary for meditation and mindfulness practice. With over 200 guided sessions, ambient soundscapes, and personalized meditation paths, it helps users build consistent mindfulness habits. The mood tracking feature uses sentiment analysis to recommend sessions.",
    type: "mobile",
    techStack: ["Swift", "SwiftUI", "Core ML", "CloudKit", "AVFoundation"],
    imageUrl: "/placeholder.svg",
    appStoreUrl: "https://apps.apple.com",
    challenges: "Creating seamless audio transitions between meditation segments and implementing offline-first architecture for uninterrupted sessions.",
    features: ["Guided meditations", "Sleep stories", "Mood tracking", "Breathing exercises", "Offline support"],
  },
  {
    id: "project-management",
    title: "TaskFlow",
    description: "A collaborative project management platform with real-time boards, time tracking, and analytics.",
    longDescription: "TaskFlow is a powerful project management solution designed for agile teams. It combines Kanban boards, sprint planning, and time tracking with rich analytics dashboards. Real-time collaboration features let teams work together seamlessly, with WebSocket-powered instant updates across all connected clients.",
    type: "web",
    techStack: ["React", "TypeScript", "Node.js", "PostgreSQL", "WebSocket", "Redis"],
    imageUrl: "/placeholder.svg",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    challenges: "Implementing conflict-free real-time collaborative editing with optimistic UI updates and proper conflict resolution strategies.",
    features: ["Kanban boards", "Sprint planning", "Time tracking", "Team analytics", "Real-time collaboration"],
  },
  {
    id: "ecommerce-platform",
    title: "ShopVault",
    description: "A headless e-commerce platform with dynamic product customization and multi-vendor support.",
    longDescription: "ShopVault is a modern headless e-commerce platform that empowers merchants with flexible product customization, multi-vendor marketplace capabilities, and advanced inventory management. Built with a microservices architecture, it handles high-traffic events like flash sales with ease.",
    type: "web",
    techStack: ["Next.js", "TypeScript", "GraphQL", "Stripe", "Prisma", "AWS"],
    imageUrl: "/placeholder.svg",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    challenges: "Designing a flexible product variant system that supports unlimited customization options while maintaining fast query performance at scale.",
    features: ["Multi-vendor marketplace", "Product customization", "Stripe payments", "Inventory management", "Analytics dashboard"],
  },
  {
    id: "analytics-dashboard",
    title: "DataLens",
    description: "A real-time analytics dashboard with customizable widgets, data visualization, and report generation.",
    longDescription: "DataLens transforms raw data into actionable insights through beautiful, interactive visualizations. Users can build custom dashboards with drag-and-drop widgets, set up automated reports, and create alert rules. It connects to multiple data sources and processes millions of events in near real-time.",
    type: "web",
    techStack: ["React", "D3.js", "Python", "FastAPI", "ClickHouse", "Docker"],
    imageUrl: "/placeholder.svg",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
    challenges: "Rendering complex D3.js visualizations with large datasets without blocking the main thread, using Web Workers for data processing.",
    features: ["Custom dashboards", "Real-time data", "Automated reports", "Alert system", "Multi-source connectors"],
  },
];
